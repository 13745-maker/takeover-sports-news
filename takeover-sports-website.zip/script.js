// ===================================================
// TAKEOVER SPORTS NEWS — Shared scripts
// ===================================================

// Mobile nav toggle
document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  // Tabs: News In Brief (homepage)
  const tabButtons = document.querySelectorAll('.tab-btn');
  if (tabButtons.length) {
    tabButtons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        const target = btn.getAttribute('data-tab');

        tabButtons.forEach(function (b) {
          b.setAttribute('aria-selected', 'false');
        });
        btn.setAttribute('aria-selected', 'true');

        document.querySelectorAll('.tab-panel').forEach(function (panel) {
          panel.classList.remove('active');
        });
        const activePanel = document.getElementById(target);
        if (activePanel) {
          activePanel.classList.add('active');
        }
      });
    });
  }

  // Contact form (front-end only — demonstrates validation + submit handling)
  const form = document.querySelector('.contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const status = form.querySelector('.form-status');
      const name = form.querySelector('#name').value.trim();
      const email = form.querySelector('#email').value.trim();
      const message = form.querySelector('#message').value.trim();

      if (!name || !email || !message) {
        status.textContent = 'Please fill in all required fields before sending.';
        return;
      }
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        status.textContent = 'Please enter a valid email address.';
        return;
      }
      status.textContent = 'Thanks, ' + name + ' — your message has been sent. We will reply to ' + email + ' shortly.';
      form.reset();
    });
  }
});
